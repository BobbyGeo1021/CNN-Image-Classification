"""
evaluation.py

Evaluates pipeline output quality against ground truth for:
  1. PennantList  — exact match metrics (Precision, Recall, F1, Category Accuracy)
  2. Country      — LLM judge scoring field-by-field correctness

Usage:
    python evaluation.py --doc china_janes

Output:
    evaluation/report_{doc_name}_{timestamp}.json
"""

import os
import re
import json
import argparse
from pathlib import Path
from datetime import datetime
from openai import OpenAI
from dotenv import load_dotenv
from langchain_google_genai import ChatGoogleGenerativeAI

load_dotenv()


# ── Constants ──────────────────────────────────────────────────────────────────

COUNTRY_FIELDS = [
    "country_id", "name", "full_name", "region_description",
    "headquarter_appointments", "fleet_commanders", "personnel",
    "operational_numbers", "organization", "bases", "coast_defence",
    "training", "marines", "naval_airforce", "fleet_strength", "deletions",
]

GROUND_TRUTH_DIR = Path("ground_truth/ocr_outputs")


# ── LLM client ─────────────────────────────────────────────────────────────────

def get_judge_client() -> tuple[OpenAI, str]:
    """Return OpenAI-compatible client pointed at the vLLM judge endpoint."""
    # client = OpenAI(
    #     base_url=os.environ["VLLM_BASE_URL"],
    #     api_key=os.environ.get("GOOGLE_API_KEY", "EMPTY"),
    # )
    api_key=os.environ.get("GOOGLE_API_KEY", "EMPTY")
    client = ChatGoogleGenerativeAI(model="gemini-3-flash-preview")
    model = "gemini-3-flash-preview"
    #model = os.environ["VLLM_MODEL_NAME"]
    return client, model


# ── Helpers ────────────────────────────────────────────────────────────────────

def load_json(path: Path) -> dict | None:
    """Load JSON file. Returns None if file is missing or malformed."""
    try:
        with open(path, "r") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError) as e:
        print(f"[load_json] Failed to load {path}: {e}")
        return None


def normalize(value: str | None) -> str:
    """Lowercase and strip whitespace for fuzzy-tolerant comparison."""
    return value.lower().strip() if value else ""


def get_predicted_dir(doc_name: str) -> Path:
    return Path("data") / "documents" / doc_name / "ocr_outputs"


# ── Pennant scoring ────────────────────────────────────────────────────────────

def score_pennant_list(predicted: list[dict], ground_truth: list[dict]) -> dict:
    """
    Exact match scoring for pennant list.

    Match key: (normalized vessel_name, vessel_no)
    vessel_no=None is treated as a valid key value — two None vessel_nos
    with matching names are considered the same vessel.

    Returns:
        precision, recall, f1, category_accuracy,
        true_positives, false_positives, missed,
        false_positive_vessels, missed_vessels
    """

    def make_key(entry: dict) -> tuple:
        return (normalize(entry.get("vessel_name", "")), entry.get("vessel_no"))

    pred_map = {make_key(p): p for p in predicted}
    gt_map   = {make_key(g): g for g in ground_truth}

    pred_keys = set(pred_map.keys())
    gt_keys   = set(gt_map.keys())
    tp_keys   = pred_keys & gt_keys

    precision = len(tp_keys) / len(pred_keys) if pred_keys else 0.0
    recall    = len(tp_keys) / len(gt_keys)   if gt_keys   else 0.0
    f1 = (2 * precision * recall / (precision + recall)) if (precision + recall) else 0.0

    # Category accuracy — among true positives, how many have the correct category?
    category_matches = sum(
        1 for k in tp_keys
        if normalize(pred_map[k].get("category", "")) == normalize(gt_map[k].get("category", ""))
    )
    category_accuracy = category_matches / len(tp_keys) if tp_keys else 0.0

    false_positive_vessels = [pred_map[k].get("vessel_name") for k in pred_keys - gt_keys]
    missed_vessels         = [gt_map[k].get("vessel_name")   for k in gt_keys - pred_keys]

    return {
        "precision":              round(precision, 3),
        "recall":                 round(recall, 3),
        "f1":                     round(f1, 3),
        "category_accuracy":      round(category_accuracy, 3),
        "true_positives":         len(tp_keys),
        "false_positives":        len(false_positive_vessels),
        "missed":                 len(missed_vessels),
        "false_positive_vessels": false_positive_vessels,
        "missed_vessels":         missed_vessels,
    }


# ── Country LLM judge ──────────────────────────────────────────────────────────

JUDGE_PROMPT = """You are an expert evaluator for structured data extraction from naval reference documents.

You will compare a PREDICTED country record against a GROUND TRUTH country record extracted from Jane's Fighting Ships.

## Ground Truth
{ground_truth}

## Predicted Output
{predicted}

## Your Task

Evaluate each field listed below. For every field, assign one verdict:
- correct     : content matches ground truth (minor formatting differences are acceptable)
- partial     : some content is right but key details are missing or slightly wrong
- missing     : field is null or empty in predicted but present in ground truth
- hallucinated: field contains content not present in ground truth

Fields to evaluate:
{fields}

## Output Format

Write your evaluation in this exact format:

FIELD VERDICTS:
country_id: <verdict> — <one line reason>
name: <verdict> — <one line reason>
full_name: <verdict> — <one line reason>
region_description: <verdict> — <one line reason>
headquarter_appointments: <verdict> — <one line reason>
fleet_commanders: <verdict> — <one line reason>
personnel: <verdict> — <one line reason>
operational_numbers: <verdict> — <one line reason>
organization: <verdict> — <one line reason>
bases: <verdict> — <one line reason>
coast_defence: <verdict> — <one line reason>
training: <verdict> — <one line reason>
marines: <verdict> — <one line reason>
naval_airforce: <verdict> — <one line reason>
fleet_strength: <verdict> — <one line reason>
deletions: <verdict> — <one line reason>

KEY ISSUES:
- <list any major problems, hallucinations, or systematic errors>

OVERALL SCORE: <a single decimal number between 0.0 and 1.0>
"""


def judge_country(
    predicted: dict,
    ground_truth: dict,
    client: ChatGoogleGenerativeAI,
    model: str,
) -> dict:
    """
    Send predicted and ground truth country dicts to LLM judge.
    Returns per-field verdicts, key issues, and an overall score.
    Plain text response — no structured output to avoid crashes on malformed JSON.
    """
    prompt = JUDGE_PROMPT.format(
        ground_truth=json.dumps(ground_truth, indent=2),
        predicted=json.dumps(predicted, indent=2),
        fields="\n".join(COUNTRY_FIELDS),
    )

    try:
        response = client.invoke(prompt)
        
        # Handle both string and list response formats
        if isinstance(response.content, str):
            raw_text = response.content
        elif isinstance(response.content, list):
            # Extract text from multimodal content list
            text_parts = [item.get("text", "") if isinstance(item, dict) else str(item) 
                          for item in response.content]
            raw_text = "".join(text_parts)
        else:
            raw_text = str(response.content)
    except Exception as e:
        print(f"[judge_country] LLM call failed: {e}")
        return {"error": str(e), "overall_score": None, "field_verdicts": {}, "raw": ""}

    # Parse field verdicts from plain text
    field_verdicts = {}
    for field in COUNTRY_FIELDS:
        pattern = rf"{re.escape(field)}:\s*(correct|partial|missing|hallucinated)"
        match = re.search(pattern, raw_text, re.IGNORECASE)
        field_verdicts[field] = match.group(1).lower() if match else "unknown"

    # Parse overall score
    score_match = re.search(r"OVERALL SCORE[:\s]+([0-9]+\.?[0-9]*)", raw_text, re.IGNORECASE)
    overall_score = float(score_match.group(1)) if score_match else None

    # Count verdict types
    verdict_counts = {v: 0 for v in ["correct", "partial", "missing", "hallucinated", "unknown"]}
    for verdict in field_verdicts.values():
        verdict_counts[verdict] = verdict_counts.get(verdict, 0) + 1

    return {
        "overall_score":  overall_score,
        "field_verdicts": field_verdicts,
        "verdict_counts": verdict_counts,
        "raw":            raw_text,
    }


# ── Per-page evaluation ────────────────────────────────────────────────────────

def evaluate_page(
    page_idx: int,
    pred_dir: Path,
    client: OpenAI,
    model: str,
) -> dict:
    """Load ground truth and predicted JSON for one page, run all evaluations."""
    page_name = f"page_{page_idx}.json"
    print(f"\n[evaluate_page] Evaluating {page_name}")

    gt_data   = load_json(GROUND_TRUTH_DIR / page_name)
    pred_data = load_json(pred_dir / page_name)

    result = {
        "page": page_idx,
        "pennant_list": None,
        "country":      None,
        "skipped":      [],
    }

    if not gt_data:
        print(f"[evaluate_page] No ground truth for {page_name} — skipping")
        result["skipped"].append("no_ground_truth")
        return result

    if not pred_data:
        print(f"[evaluate_page] No predicted output for {page_name} — skipping")
        result["skipped"].append("no_prediction")
        return result

    gt_so   = gt_data.get("structured_output", {})
    pred_so = pred_data.get("structured_output", {})

    # ── Pennant list ───────────────────────────────────────────────────────────
    gt_pennants   = (gt_so.get("pennant_list") or {}).get("pennants", [])
    pred_pennants = (pred_so.get("pennant_list") or {}).get("pennants", [])

    if gt_pennants:
        print(f"[evaluate_page] Scoring pennant list ({len(gt_pennants)} GT vessels)")
        result["pennant_list"] = score_pennant_list(pred_pennants, gt_pennants)
    else:
        print(f"[evaluate_page] No pennant list in ground truth — skipping")
        result["skipped"].append("no_gt_pennant_list")

    # ── Country ────────────────────────────────────────────────────────────────
    gt_country   = gt_so.get("country")
    pred_country = pred_so.get("country")

    if gt_country:
        if pred_country:
            print(f"[evaluate_page] Running LLM judge on country")
            result["country"] = judge_country(pred_country, gt_country, client, model)
        else:
            print(f"[evaluate_page] Country missing in prediction")
            result["country"] = {
                "overall_score":  0.0,
                "field_verdicts": {f: "missing" for f in COUNTRY_FIELDS},
                "verdict_counts": {"missing": len(COUNTRY_FIELDS)},
                "raw":            "No country extracted by model.",
            }
    else:
        print(f"[evaluate_page] No country in ground truth — skipping")
        result["skipped"].append("no_gt_country")

    return result


# ── Summary ────────────────────────────────────────────────────────────────────

def compute_summary(page_results: list[dict]) -> dict:
    """Aggregate per-page results into overall summary metrics."""

    pennant_scores = [
        p["pennant_list"] for p in page_results
        if p.get("pennant_list") is not None
    ]
    country_scores = [
        p["country"] for p in page_results
        if p.get("country") is not None and p["country"].get("overall_score") is not None
    ]

    summary = {}

    if pennant_scores:
        summary["pennant"] = {
            "avg_precision":         round(sum(s["precision"]        for s in pennant_scores) / len(pennant_scores), 3),
            "avg_recall":            round(sum(s["recall"]           for s in pennant_scores) / len(pennant_scores), 3),
            "avg_f1":                round(sum(s["f1"]               for s in pennant_scores) / len(pennant_scores), 3),
            "avg_category_accuracy": round(sum(s["category_accuracy"] for s in pennant_scores) / len(pennant_scores), 3),
            "total_true_positives":  sum(s["true_positives"]  for s in pennant_scores),
            "total_false_positives": sum(s["false_positives"] for s in pennant_scores),
            "total_missed":          sum(s["missed"]          for s in pennant_scores),
            "pages_evaluated":       len(pennant_scores),
        }

    if country_scores:
        avg_score = sum(s["overall_score"] for s in country_scores) / len(country_scores)

        # Aggregate verdict counts across all pages
        total_verdicts: dict[str, int] = {}
        for s in country_scores:
            for verdict, count in s.get("verdict_counts", {}).items():
                total_verdicts[verdict] = total_verdicts.get(verdict, 0) + count

        summary["country"] = {
            "avg_overall_score":   round(avg_score, 3),
            "total_verdict_counts": total_verdicts,
            "pages_evaluated":     len(country_scores),
        }

    return summary


# ── Main runner ────────────────────────────────────────────────────────────────

def run_evaluation(doc_name: str) -> dict:
    pred_dir = get_predicted_dir(doc_name)
    client, model = get_judge_client()

    print(f"\n{'='*60}")
    print(f"Evaluating: {doc_name}")
    print(f"Ground truth: {GROUND_TRUTH_DIR}")
    print(f"Predictions:  {pred_dir}")
    print(f"Judge model:  {model}")
    print(f"{'='*60}")

    # Discover pages from ground truth directory
    gt_pages = sorted(GROUND_TRUTH_DIR.glob("page_*.json"))
    if not gt_pages:
        raise FileNotFoundError(f"No ground truth pages found in {GROUND_TRUTH_DIR}")

    page_indices = [int(p.stem.replace("page_", "")) for p in gt_pages]
    print(f"Pages to evaluate: {page_indices}")

    page_results = []
    for idx in page_indices:
        result = evaluate_page(idx, pred_dir, client, model)
        page_results.append(result)

    summary = compute_summary(page_results)

    report = {
        "doc_name":   doc_name,
        "timestamp":  datetime.now().isoformat(),
        "judge_model": model,
        "summary":    summary,
        "pages":      page_results,
    }

    return report


def save_report(report: dict, doc_name: str) -> Path:
    output_dir = Path("evaluation")
    output_dir.mkdir(exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_path = output_dir / f"report_{doc_name}_{timestamp}.json"

    with open(output_path, "w") as f:
        json.dump(report, f, indent=2)

    print(f"\n[save_report] Report saved to: {output_path}")
    return output_path


# ── Entry point ────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    # parser = argparse.ArgumentParser(description="Evaluate pipeline output quality")
    # parser.add_argument(
    #     "--doc",
    #     required=True,
    #     help="Document name (e.g. china_janes)",
    # )
    # args = parser.parse_args()

    # report = run_evaluation(args.doc)
    # save_report(report, args.doc)
    doc_name = "china_janes"
    report = run_evaluation(doc_name)
    save_report(report, doc_name)

    # Print summary to console
    print(f"\n{'='*60}")
    print("SUMMARY")
    print(f"{'='*60}")
    print(json.dumps(report["summary"], indent=2))