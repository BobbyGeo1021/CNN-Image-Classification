"""Single page extraction graph module.

Pipeline per page:
  START
    → select_schema  (Qwen 3.6 vision  image → schema list)
        ↓ conditional edge
    [no schemas]  → END  (page skipped entirely)
    [schemas found]
        → ocr_node   (Chandra OCR vision  image → markdown text)
        → extract_so (Qwen 3.6 text    ocr_text + prompt → structured output)
    → END
"""

import base64
import os
import yaml

from langchain.messages import HumanMessage
from langchain_openai import ChatOpenAI
from langchain_core.language_models.chat_models import BaseChatModel
from langgraph.graph import StateGraph, START, END
from langchain_google_genai import ChatGoogleGenerativeAI

from core.schemas.models import (
    PennantList,
    Country,
    SchemaSelection,
    SchemaType,
    PageExtractionState,
)
from dotenv import load_dotenv



load_dotenv()
api_key = os.getenv("GOOGLE_API_KEY")

# ── Schema → Output model mapping ─────────────────────────────────────────────
# ClassInfoList intentionally excluded  model retained in models.py for future use

KEY_CLASS_MAPPING = {
    SchemaType.extract_country: Country,
    SchemaType.extract_pennant_list: PennantList,
}


# ── Prompt loader ──────────────────────────────────────────────────────────────

def load_all_prompts() -> dict:
    """Load prompts.yaml from path set in PROMPT_FILE_PATH env var."""
    prompt_path = os.environ["PROMPT_FILE_PATH"]
    with open(prompt_path, "r") as f:
        return yaml.safe_load(f)


# ── LLM singletons ─────────────────────────────────────────────────────────────
# Two separate vLLM instances: Qwen 3.6 (schema selection + extraction)
# and Chandra OCR (image → markdown text). Both OpenAI-compatible endpoints.

_llm: BaseChatModel = None      # Qwen 3.6
_ocr_llm: BaseChatModel = None  # Chandra OCR 2


# def get_llm() -> BaseChatModel:
#     """Return singleton Qwen 3.6 instance.
#     Reads VLLM_BASE_URL, VLLM_MODEL_NAME, VLLM_API_KEY from environment."""
#     global _llm
#     if _llm is None:
#         _llm = ChatOpenAI(
#             model=os.environ["VLLM_MODEL_NAME"],
#             base_url=os.environ["VLLM_BASE_URL"],
#             api_key=os.environ.get("VLLM_API_KEY", "EMPTY"),
#             temperature=0,
#         )
#     return _llm

def get_llm() -> BaseChatModel:
    """
    Returns a singleton LLM instance.
    Initializes only on the first call to ensure env vars are loaded.
    """
    global _llm
    if _llm is None:
        # Env variables are guaranteed to be checked here, not at import
        _llm = ChatGoogleGenerativeAI(model="gemini-3-flash-preview")

    return _llm

def get_ocr_llm() -> BaseChatModel:
    """
    Returns a singleton LLM instance.
    Initializes only on the first call to ensure env vars are loaded.
    """
    global _ocr_llm
    if _ocr_llm is None:
        # Env variables are guaranteed to be checked here, not at import
        _ocr_llm = ChatGoogleGenerativeAI(model="gemini-3-flash-preview")

    return _ocr_llm


# def get_ocr_llm() -> BaseChatModel:
#     """Return singleton Chandra OCR 2 instance (separate vLLM port).
#     Reads CHANDRA_OCR_BASE_URL, CHANDRA_OCR_MODEL_NAME, CHANDRA_OCR_API_KEY from environment."""
#     global _ocr_llm
#     if _ocr_llm is None:
#         _ocr_llm = ChatOpenAI(
#             model=os.environ["CHANDRA_OCR_MODEL_NAME"],
#             base_url=os.environ["CHANDRA_OCR_BASE_URL"],
#             api_key=os.environ.get("CHANDRA_OCR_API_KEY", "EMPTY"),
#             temperature=0,
#         )
#     return _ocr_llm


def reset_llm() -> None:
    """Reset Qwen 3.6 singleton. Call between evaluation model runs."""
    global _llm
    _llm = None


def reset_ocr_llm() -> None:
    """Reset Chandra OCR singleton. Call between evaluation model runs."""
    global _ocr_llm
    _ocr_llm = None


# ── Image loader ───────────────────────────────────────────────────────────────

def load_image(img_path: str) -> dict:
    """Read image from disk and return OpenAI-compatible vision content dict."""
    with open(img_path, "rb") as f:
        image_base64 = base64.b64encode(f.read()).decode("utf-8")
    return {
        "type": "image_url",
        "image_url": {"url": f"data:image/png;base64,{image_base64}"},
    }


# ── Nodes ──────────────────────────────────────────────────────────────────────

def select_schema(state: PageExtractionState) -> PageExtractionState:
    """Node 1: Send raw page image to Qwen 3.6 to detect which schemas apply.

    Uses vision input (image) because Chandra OCR has not run yet.
    Result stored in state.selected_schemas.
    """
    print(f"[select_schema] Processing: {state.img_path}")

    all_prompts = load_all_prompts()
    prompt = all_prompts["schema_selection"]
    print("[select_schema] Loaded prompt for schema selection")


    structured_llm = get_llm().with_structured_output(
        schema=SchemaSelection, method="json_schema"
    )
    img_dict = load_image(state.img_path)
    print("[select_schema] Loaded image")

    message = HumanMessage(content=[
        {"type": "text", "text": prompt},
        img_dict,
    ])

    response = structured_llm.invoke([message])
    state.selected_schemas = response.selected_schemas

    print(f"[select_schema] Selected: {[s.value for s in state.selected_schemas]}")
    return state


def ocr_node(state: PageExtractionState) -> PageExtractionState:
    """Node 2 (conditional): Send page image to Chandra OCR → store markdown in state.ocr_text.

    Only reached when select_schema found at least one relevant schema.
    """
    print(f"[ocr_node] Running Chandra OCR on: {state.img_path}")

    # Placeholder prompt  replace with Chandra-specific instruction when finalised
    ocr_prompt = (
        "Extract all the text from this page exactly as it appears. "
        "Output in markdown format preserving all headings, tables, and structure."
    )
    img_dict = load_image(state.img_path)

    message = HumanMessage(content=[
        {"type": "text", "text": ocr_prompt},
        img_dict,
    ])

    response = get_ocr_llm().invoke([message])
    # Extract text from response - handle both string and list formats
    if isinstance(response.content, str):
        state.ocr_text = response.content
    elif isinstance(response.content, list):
        state.ocr_text = " ".join(
            block["text"] for block in response.content
            if isinstance(block, dict) and block.get("type") == "text"
        )
    else:
        state.ocr_text = str(response.content)

    print(f"[ocr_node] OCR complete  {len(state.ocr_text)} characters extracted")
    return state


def extract_so(state: PageExtractionState) -> PageExtractionState:
    """Node 3: For each selected schema, run Qwen 3.6 on OCR text to extract structured data.

    Text-only input  no image. Uses {output} variable substitution from prompts.yaml.
    Updates rolling_context.country_name when a Country is successfully extracted.
    """
    print(f"[extract_so] Extracting {len(state.selected_schemas)} schema(s)")

    all_prompts = load_all_prompts()
    ocr_text = state.ocr_text or ""

    for schema_type in state.selected_schemas:
        # Resolve prompt from nested YAML: extract.extract_country / extract.extract_pennant_list
        prompt_template = all_prompts.get("extract", {}).get(schema_type.value, "")
        if not prompt_template:
            print(f"[extract_so] No prompt found for '{schema_type.value}'  skipping")
            continue

        output_schema = KEY_CLASS_MAPPING.get(schema_type)
        if not output_schema:
            print(f"[extract_so] No schema mapping for '{schema_type.value}'  skipping")
            continue

        #rompt = prompt_template.format(output=ocr_text)
        prompt = prompt_template.format(
                output=ocr_text,
                last_pennant_category=state.rolling_context.last_pennant_category or "null",
            )

        structured_llm = get_llm().with_structured_output(
            schema=output_schema, method="json_schema"
        )

        # Text-only message  OCR already extracted the image content
        message = HumanMessage(content=prompt)
        response = structured_llm.invoke([message])

        # Carry country name forward into rolling context for subsequent pages
        if schema_type == SchemaType.extract_country and isinstance(response, Country):
            state.rolling_context.country_name = response.name
            print(f"[extract_so] Rolling context updated  country: {response.name}")
        if schema_type == SchemaType.extract_pennant_list and isinstance(response, PennantList):
            if response.pennants:
                state.rolling_context.last_pennant_category = response.pennants[-1].category

        state.outputs.append(response)
        print(f"[extract_so] Extracted: {schema_type.value}")

    return state


# ── Conditional routing ────────────────────────────────────────────────────────

def route_after_schema_selection(state: PageExtractionState) -> str:
    """Route to ocr_node if schemas were selected, otherwise skip page entirely."""
    if not state.selected_schemas:
        print("[route] No relevant schemas  skipping OCR and extraction")
        return "skip"
    return "ocr_node"


# ── Graph builder ──────────────────────────────────────────────────────────────

def build_single_page_graph():
    """Build and compile the single page extraction graph."""
    graph = StateGraph(PageExtractionState)

    graph.add_node("schema_selection", select_schema)
    graph.add_node("ocr_node", ocr_node)
    graph.add_node("extract_so", extract_so)

    graph.add_edge(START, "schema_selection")

    graph.add_conditional_edges(
        "schema_selection",
        route_after_schema_selection,
        {
            "skip": END,         # no schemas found  page done
            "ocr_node": "ocr_node",
        },
    )

    graph.add_edge("ocr_node", "extract_so")
    graph.add_edge("extract_so", END)

    return graph.compile()