import json
import os
import hashlib
from pathlib import Path
from pdf2image import convert_from_path
from langgraph.graph import StateGraph, START, END
from dotenv import load_dotenv
from single_page_graph import (
    PageExtractionState,
    build_single_page_graph,
)
load_dotenv()
from core.schemas.models import (
    Country,
    PennantList,
    StructuredOutput,
    PageOutput,
    DirectoryProcessingState,
    RollingContext,
    SchemaType,
)


# ── Cache helpers ──────────────────────────────────────────────────────────────

# Maps type name string (stored in cache) back to the Pydantic model class.
# ClassInfoList intentionally excluded — not part of current pipeline.
OUTPUT_TYPE_MAP = {
    "Country": Country,
    "PennantList": PennantList,
}


def compute_schema_hash() -> str:
    """Hash prompts.yaml + models.py → 8-char cache version key.
    Any change to prompts or schemas produces a new hash → automatic cache invalidation."""
    hasher = hashlib.md5()
    for filepath in ["prompts.yaml", "core/schemas/models.py"]:
        try:
            with open(filepath, "rb") as f:
                hasher.update(f.read())
        except FileNotFoundError:
            pass
    return hasher.hexdigest()[:8]


# ── Node 1 ─────────────────────────────────────────────────────────────────────

def process_pages_iteratively(state: DirectoryProcessingState):
    """Node 1: Run the single-page extraction graph on every page image.

    - Sorts page images by filename for deterministic order.
    - Caches each page result to disk (keyed by schema_hash).
      Cache hit: skip OCR + LLM calls entirely.
      Cache miss: run single_page_graph, then write result to cache.
    - Carries rolling_context (country_name, pennants) forward between pages.
    """
    print("[process_pages_iteratively] Starting iterative page processing")

    input_path = Path(state.input_dir)
    image_files = sorted(
        [f for f in input_path.iterdir() if f.suffix.lower() in [".png", ".jpg", ".jpeg"]],
        key=lambda x: x.name,
    )
    print(f"[process_pages_iteratively] Found {len(image_files)} images")

    single_page_graph = build_single_page_graph()
    cache_dir = Path(f"processed/{state.doc_name}/cache/{state.schema_hash}")
    cache_dir.mkdir(parents=True, exist_ok=True)

    page_extraction_results = {}
    rolling_context = state.rolling_context

    for img_path in image_files:
        print(f"[process_pages_iteratively] Processing: {img_path}")

        img_name = Path(img_path).stem
        cache_file = cache_dir / f"{img_name}_state.json"

        # ── Cache hit ──────────────────────────────────────────────────────────
        if cache_file.exists():
            print(f"[process_pages_iteratively] Cache hit: {img_name}")
            try:
                with open(cache_file, "r") as f:
                    cached_data = json.load(f)

                # Reconstruct typed outputs from stored {__type__, data} dicts
                outputs = []
                for item in cached_data.get("outputs", []):
                    output_type = item.get("__type__")
                    if output_type in OUTPUT_TYPE_MAP:
                        outputs.append(OUTPUT_TYPE_MAP[output_type](**item["data"]))
                    else:
                        print(f"[process_pages_iteratively] Unknown output type '{output_type}' in cache — skipping")

                # Reconstruct selected_schemas as SchemaType enums
                selected_schemas = []
                for s in cached_data.get("selected_schemas", []):
                    try:
                        selected_schemas.append(SchemaType(s))
                    except ValueError:
                        print(f"[process_pages_iteratively] Unknown schema '{s}' in cache — skipping")

                final_page_state = PageExtractionState(
                    img_path=Path(cached_data["img_path"]),
                    rolling_context=RollingContext(**cached_data["rolling_context"]),
                    selected_schemas=selected_schemas,
                    ocr_text=cached_data.get("ocr_text"),
                    outputs=outputs,
                )

                page_extraction_results[img_path] = final_page_state
                rolling_context = final_page_state.rolling_context
                print(f"[process_pages_iteratively] Loaded from cache: {img_name}")
                continue

            except Exception as e:
                print(f"[process_pages_iteratively] Cache load error for {img_name}: {e} — reprocessing")

        # ── Cache miss: run graph ──────────────────────────────────────────────
        page_state = PageExtractionState(
            img_path=img_path,
            rolling_context=rolling_context,
            selected_schemas=[],
            outputs=[],
        )

        final_page_state = single_page_graph.invoke(page_state)

        page_extraction_results[img_path] = final_page_state
        rolling_context = final_page_state.get("rolling_context")

        # ── Write to cache ─────────────────────────────────────────────────────
        try:
            cache_data = {
                "img_path": str(final_page_state.get("img_path")),
                "rolling_context": final_page_state.get("rolling_context").model_dump(),
                "selected_schemas": [
                    s.value for s in (final_page_state.get("selected_schemas") or [])
                ],
                "ocr_text": final_page_state.get("ocr_text"),
                # Store each output with its type name so it can be reconstructed on load
                "outputs": [
                    {"__type__": type(output).__name__, "data": output.model_dump(mode="dict")}
                    for output in (final_page_state.get("outputs") or [])
                ],
            }
            with open(cache_file, "w") as f:
                json.dump(cache_data, f, indent=2)
            print(f"[process_pages_iteratively] Cached result: {img_name}")
        except Exception as e:
            print(f"[process_pages_iteratively] Cache write error for {img_name}: {e}")

        print(f"[process_pages_iteratively] Completed: {img_path}")

    print(f"[process_pages_iteratively] Processed {len(page_extraction_results)} pages")
    return {
        "page_extraction_results": page_extraction_results,
        "rolling_context": rolling_context,
    }


# ── Node 2 ─────────────────────────────────────────────────────────────────────

def generate_final_outputs(state: DirectoryProcessingState):
    """Node 2: Build PageOutput objects and combined_output from page_extraction_results.

    combined_output accumulates across all pages:
      - country:      first Country found across all pages
      - pennant_list: first PennantList found (pennants accumulate across pages)
    """
    print("[generate_final_outputs] Starting final output generation")

    combined_output = {
        "country": None,
        "pennant_list": None,
    }

    for img_path, page_state in state.page_extraction_results.items():
        img_name = Path(img_path).name

        country_info = None
        pennant_list_info = None

        for output in page_state.outputs:
            if isinstance(output, Country):
                country_info = output
            elif isinstance(output, PennantList):
                pennant_list_info = output

        structured_output = StructuredOutput(
            country=country_info,
            pennant_list=pennant_list_info,
        )

        state.page_outputs[img_name] = PageOutput(
            structured_output=structured_output,
            markdown="",  # populated by generate_markdown
        )

        # Accumulate into combined_output — first occurrence wins for country
        if country_info and combined_output["country"] is None:
            combined_output["country"] = country_info.model_dump(mode="dict")

        # Accumulate pennants across pages (pennant list may span multiple pages)
        if pennant_list_info:
            if combined_output["pennant_list"] is None:
                combined_output["pennant_list"] = pennant_list_info.model_dump(mode="dict")
            else:
                combined_output["pennant_list"]["pennants"].extend(
                    pennant_list_info.model_dump(mode="dict")["pennants"]
                )

    state.combined_output = combined_output

    print(f"[generate_final_outputs] Generated outputs for {len(state.page_outputs)} pages")
    return state


# ── Node 3 ─────────────────────────────────────────────────────────────────────

def generate_markdown(state: DirectoryProcessingState):
    """Node 3: Render structured data into Markdown via Jinja2 templates.

    Produces:
      - Per-page .md files  → processed/{doc_name}/markdown/
      - combined_output.md  → processed/{doc_name}/
    """
    print("[generate_markdown] Starting markdown generation")

    from jinja2 import Environment, FileSystemLoader

    template_dir = Path("templates")
    env = Environment(loader=FileSystemLoader(str(template_dir)))

    country_template = env.get_template("country.jinja2")
    pennant_template = env.get_template("pennant_list.jinja2")

    # ── Per-page markdown ──────────────────────────────────────────────────────
    for img_name, page_output in state.page_outputs.items():
        print(f"[generate_markdown] Generating markdown for: {img_name}")

        so = page_output.structured_output
        parts = []

        if so.country:
            parts.append(country_template.render(
                country=so.country.model_dump(mode="dict")
            ).strip())

        if so.pennant_list:
            parts.append(pennant_template.render(
                pennants=so.pennant_list.model_dump(mode="dict").get("pennants", [])
            ).strip())

        page_output.markdown = "\n\n".join(parts)
        print(f"[generate_markdown] {img_name}: {len(page_output.markdown)} chars")

    # ── Combined markdown ──────────────────────────────────────────────────────
    print("[generate_markdown] Generating combined document markdown")
    combined_parts = []

    if state.combined_output.get("country"):
        combined_parts.append(country_template.render(
            country=state.combined_output["country"]
        ).strip())
        combined_parts.append("---\n")

    if state.combined_output.get("pennant_list"):
        combined_parts.append(pennant_template.render(
            pennants=state.combined_output["pennant_list"].get("pennants", [])
        ).strip())

    state.combined_markdown = "\n\n".join(combined_parts)
    print(f"[generate_markdown] Combined markdown: {len(state.combined_markdown)} chars")

    # ── Save files ─────────────────────────────────────────────────────────────
    output_dir = Path(f"processed/{state.doc_name}")
    output_dir.mkdir(parents=True, exist_ok=True)

    markdown_dir = output_dir / "markdown"
    markdown_dir.mkdir(parents=True, exist_ok=True)

    for img_name, page_output in state.page_outputs.items():
        page_md_file = markdown_dir / f"{Path(img_name).stem}.md"
        with open(page_md_file, "w") as f:
            f.write(page_output.markdown)
        print(f"[generate_markdown] Saved: {page_md_file}")

    combined_md_file = output_dir / "combined_output.md"
    with open(combined_md_file, "w") as f:
        f.write(state.combined_markdown)
    print(f"[generate_markdown] Saved combined: {combined_md_file}")

    print("[generate_markdown] Markdown generation complete")
    return state


# ── Graph builder ──────────────────────────────────────────────────────────────

def build_directory_graph():
    """Build the 3-node directory processing graph."""
    print("[build_directory_graph] Building graph")

    graph = StateGraph(DirectoryProcessingState)

    graph.add_node("process_pages_iteratively", process_pages_iteratively)
    graph.add_node("generate_final_outputs", generate_final_outputs)
    graph.add_node("generate_markdown", generate_markdown)

    graph.add_edge(START, "process_pages_iteratively")
    graph.add_edge("process_pages_iteratively", "generate_final_outputs")
    graph.add_edge("generate_final_outputs", "generate_markdown")
    graph.add_edge("generate_markdown", END)

    return graph.compile()


# ── Entry point ────────────────────────────────────────────────────────────────

def process_pdf(pdf_path: str):
    """Convert PDF to images, run the extraction pipeline, save JSON + markdown outputs.

    Directory layout created:
      data/documents/{name}/images/        — page PNGs
      data/documents/{name}/ocr_outputs/   — per-page JSON
      data/documents/{name}/info.json      — image/json pairs manifest
      processed/{name}/markdown/           — per-page markdown
      processed/{name}/combined_output.md  — full document markdown
    """
    pdf_file = Path(pdf_path)
    if not pdf_file.exists() or pdf_file.suffix.lower() != ".pdf":
        raise FileNotFoundError(f"Invalid PDF path: {pdf_path}")

    # Setup directories
    data_dir = Path("data") / "documents" / pdf_file.stem
    images_dir = data_dir / "images"
    ocr_outputs_dir = data_dir / "ocr_outputs"
    images_dir.mkdir(parents=True, exist_ok=True)
    ocr_outputs_dir.mkdir(parents=True, exist_ok=True)

    schema_hash = compute_schema_hash()

    # Convert PDF pages to PNG images
    images = convert_from_path(str(pdf_file))
    for i, img in enumerate(images):
        img.save(str(images_dir / f"page_{i}.png"), "PNG")

    # Write image/json manifest
    info_data = [
        {"image_name": f"page_{i}.png", "json_name": f"page_{i}.json"}
        for i in range(len(images))
    ]
    with open(data_dir / "info.json", "w") as f:
        json.dump(info_data, f, indent=2)

    # Build initial state and run graph
    initial_state = DirectoryProcessingState(
        input_dir=images_dir,
        doc_name=pdf_file.stem,
        schema_hash=schema_hash,
        rolling_context=RollingContext(),
        page_extraction_results={},
        page_outputs={},
        combined_output={},
        combined_markdown="",
    )

    final_state = build_directory_graph().invoke(initial_state)

    # Save per-page JSON to ocr_outputs/
    for img_name, page_output in final_state.get("page_outputs", {}).items():
        page_idx = Path(img_name).stem
        output_data = {
            "structured_output": {},
            "markdown": page_output.markdown or "",
        }

        so = page_output.structured_output
        if so.country:
            output_data["structured_output"]["country"] = so.country.model_dump(mode="dict")
        if so.pennant_list:
            output_data["structured_output"]["pennant_list"] = so.pennant_list.model_dump(mode="dict")

        output_file = ocr_outputs_dir / f"{page_idx}.json"
        with open(output_file, "w") as f:
            json.dump(output_data, f, indent=2)

    return (
        final_state.get("page_outputs"),
        final_state.get("combined_output"),
        final_state.get("combined_markdown"),
    )


if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()

    pdf_path = "./data/china_janes.pdf"
    page_outputs, combined_output, combined_markdown = process_pdf(pdf_path)