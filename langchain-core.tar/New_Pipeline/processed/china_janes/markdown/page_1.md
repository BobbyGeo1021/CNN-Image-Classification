# Pennant List


## Putuo Shan

- **Vessel Number:** 939
- **Category:** Principal amphibious warfare units


## Tiantai Shan

- **Vessel Number:** 940
- **Category:** Principal amphibious warfare units


## Longhu Shan

- **Vessel Number:** 980
- **Category:** Principal amphibious warfare units


## Dabie Shan

- **Vessel Number:** 981
- **Category:** Principal amphibious warfare units


## Taihang Shan

- **Vessel Number:** 982
- **Category:** Principal amphibious warfare units


## Qilian Shan

- **Vessel Number:** 985
- **Category:** Principal amphibious warfare units


## Wanyang Shan

- **Vessel Number:** 986
- **Category:** Principal amphibious warfare units


## Wuzhi Shan

- **Vessel Number:** 987
- **Category:** Principal amphibious warfare units


## Yimeng Shan

- **Vessel Number:** 988
- **Category:** Principal amphibious warfare units


## Changbai Shan

- **Vessel Number:** 989
- **Category:** Principal amphibious warfare units


## Emei Shan

- **Vessel Number:** 991
- **Category:** Principal amphibious warfare units


## Huading Shan

- **Vessel Number:** 992
- **Category:** Principal amphibious warfare units


## Luoxiao Shan

- **Vessel Number:** 993
- **Category:** Principal amphibious warfare units


## Daiyun Shan

- **Vessel Number:** 994
- **Category:** Principal amphibious warfare units


## Wanyan Shan

- **Vessel Number:** 995
- **Category:** Principal amphibious warfare units


## Laotie Shan

- **Vessel Number:** 996
- **Category:** Principal amphibious warfare units


## Yunwu Shan

- **Vessel Number:** 997
- **Category:** Principal amphibious warfare units


## Kunlun Shan

- **Vessel Number:** 998
- **Category:** Principal amphibious warfare units


## Jinggang Shan

- **Vessel Number:** 999
- **Category:** Principal amphibious warfare units


## Fenghua

- **Vessel Number:** 703
- **Category:** Principal amphibious warfare units


## Huoqiu

- **Vessel Number:** 704
- **Category:** Principal amphibious warfare units


## Zhangjiagang

- **Vessel Number:** 705
- **Category:** Principal amphibious warfare units


## Jingjiang

- **Vessel Number:** 706
- **Category:** Principal amphibious warfare units


## Kunshan

- **Vessel Number:** 707
- **Category:** Principal amphibious warfare units


## Renhuai

- **Vessel Number:** 710
- **Category:** Principal amphibious warfare units


## Jiangshan

- **Vessel Number:** 711
- **Category:** Principal amphibious warfare units


## Rudong

- **Vessel Number:** 712
- **Category:** Principal amphibious warfare units


## Zhuji

- **Vessel Number:** 713
- **Category:** Principal amphibious warfare units


## �

- **Vessel Number:** 714
- **Category:** Principal amphibious warfare units


## Wenling

- **Vessel Number:** 715
- **Category:** Principal amphibious warfare units


## Pingdu

- **Vessel Number:** 720
- **Category:** Principal amphibious warfare units


## Changyi

- **Vessel Number:** 721
- **Category:** Principal amphibious warfare units


## Yangshuo

- **Vessel Number:** 722
- **Category:** Principal amphibious warfare units


## Yongsheng

- **Vessel Number:** 723
- **Category:** Principal amphibious warfare units


## Daxin

- **Vessel Number:** 724
- **Category:** Principal amphibious warfare units


## Huarong

- **Vessel Number:** 725
- **Category:** Principal amphibious warfare units


## Rongjiang

- **Vessel Number:** 726
- **Category:** Principal amphibious warfare units


## Qionghai

- **Vessel Number:** 727
- **Category:** Principal amphibious warfare units


## Hejian

- **Vessel Number:** 728
- **Category:** Principal amphibious warfare units


## Chishui

- **Vessel Number:** 729
- **Category:** Principal amphibious warfare units


## Qingzhou

- **Vessel Number:** 730
- **Category:** Principal amphibious warfare units


## Yucheng

- **Vessel Number:** 731
- **Category:** Principal amphibious warfare units


## Wudi

- **Vessel Number:** 732
- **Category:** Principal amphibious warfare units


## Xuanwei

- **Vessel Number:** 733
- **Category:** Principal amphibious warfare units


## Rongcheng

- **Vessel Number:** 734
- **Category:** Principal amphibious warfare units


## Huimin

- **Vessel Number:** 735
- **Category:** Principal amphibious warfare units


## Donggang

- **Vessel Number:** 736
- **Category:** Principal amphibious warfare units


## Zhijiang

- **Vessel Number:** 737
- **Category:** Principal amphibious warfare units


## Chibi

- **Vessel Number:** 738
- **Category:** Principal amphibious warfare units


## �

- **Vessel Number:** 739
- **Category:** Principal amphibious warfare units


## Xiaoyi

- **Vessel Number:** 741
- **Category:** Principal amphibious warfare units


## Taishan

- **Vessel Number:** 742
- **Category:** Principal amphibious warfare units


## Changshu

- **Vessel Number:** 743
- **Category:** Principal amphibious warfare units


## Heshan

- **Vessel Number:** 744
- **Category:** Principal amphibious warfare units


## Luxi

- **Vessel Number:** 745
- **Category:** Principal amphibious warfare units


## Kaiping

- **Vessel Number:** 746
- **Category:** Principal amphibious warfare units


## ex-806 Zhijiang

- **Vessel Number:** None
- **Category:** Principal amphibious warfare units


## ex-816 Haimen

- **Vessel Number:** None
- **Category:** Principal amphibious warfare units


## ex-839 Liuyang

- **Vessel Number:** None
- **Category:** Principal amphibious warfare units


## Bi Sheng

- **Vessel Number:** 891
- **Category:** Principal amphibious warfare units


## Hua Luogeng

- **Vessel Number:** 892
- **Category:** Principal amphibious warfare units


## Zhong Tianyou

- **Vessel Number:** 893
- **Category:** Principal amphibious warfare units


## Li Siguang

- **Vessel Number:** 894
- **Category:** Principal amphibious warfare units


## Wu Yunyu

- **Vessel Number:** 895
- **Category:** Principal amphibious warfare units


## Haiwanxing

- **Vessel Number:** 792
- **Category:** Principal amphibious warfare units


## Tianlangxing

- **Vessel Number:** 794
- **Category:** Principal amphibious warfare units


## Tianshuxing

- **Vessel Number:** 795
- **Category:** Principal amphibious warfare units


## Tianquanxing

- **Vessel Number:** 797
- **Category:** Principal amphibious warfare units


## Yuhengxing

- **Vessel Number:** 798
- **Category:** Principal amphibious warfare units


## Jinxing

- **Vessel Number:** 799
- **Category:** Principal amphibious warfare units


## Dong Biao 265

- **Vessel Number:** 265
- **Category:** Principal amphibious warfare units


## Nan Biao 467

- **Vessel Number:** 467
- **Category:** Principal amphibious warfare units


## Changxing Dao

- **Vessel Number:** 861
- **Category:** Principal amphibious warfare units


## Chongming Dao

- **Vessel Number:** 862
- **Category:** Principal amphibious warfare units


## Yongxing Dao

- **Vessel Number:** 863
- **Category:** Principal amphibious warfare units


## Haiyang Dao

- **Vessel Number:** 864
- **Category:** Principal amphibious warfare units


## Liugong Dao

- **Vessel Number:** 865
- **Category:** Principal amphibious warfare units


## Daishan Dao

- **Vessel Number:** 866
- **Category:** Principal amphibious warfare units


## Daishan Dao

- **Vessel Number:** 867
- **Category:** Principal amphibious warfare units


## Donghai Dao

- **Vessel Number:** 868
- **Category:** Principal amphibious warfare units


## Qinghai Hu

- **Vessel Number:** 885
- **Category:** Principal amphibious warfare units


## Qiandao Hu

- **Vessel Number:** 886
- **Category:** Principal amphibious warfare units


## Weishan Hu

- **Vessel Number:** 887
- **Category:** Principal amphibious warfare units


## Fuxian Hu

- **Vessel Number:** 888
- **Category:** Principal amphibious warfare units


## Tai Hu

- **Vessel Number:** 889
- **Category:** Principal amphibious warfare units


## Chao Hu

- **Vessel Number:** 890
- **Category:** Principal amphibious warfare units


## Hulun Hu

- **Vessel Number:** 901
- **Category:** Principal amphibious warfare units


## Dongping Hu

- **Vessel Number:** 902
- **Category:** Principal amphibious warfare units


## Hoh Xil Hu

- **Vessel Number:** 903
- **Category:** Principal amphibious warfare units


## Gaoyao Hu

- **Vessel Number:** 904
- **Category:** Principal amphibious warfare units


## Xiangshan

- **Vessel Number:** 701
- **Category:** Principal mine warfare forces


## Chongming

- **Vessel Number:** 702
- **Category:** Principal mine warfare forces


## Zhu Khezen

- **Vessel Number:** 872
- **Category:** Principal survey and research ships


## Qian Xuesen

- **Vessel Number:** 873
- **Category:** Principal survey and research ships


## Deng Jiaxian

- **Vessel Number:** 874
- **Category:** Principal survey and research ships


## Qian Sanqiang

- **Vessel Number:** 875
- **Category:** Principal survey and research ships


## Qian Weichang

- **Vessel Number:** 876
- **Category:** Principal survey and research ships


## Bei Ce 901

- **Vessel Number:** None
- **Category:** Intelligence vessels


## Bei Ce 902

- **Vessel Number:** None
- **Category:** Intelligence vessels


## Bei Diao 900

- **Vessel Number:** None
- **Category:** Intelligence vessels


## Bei Diao 990

- **Vessel Number:** None
- **Category:** Intelligence vessels


## Bei Diao 991

- **Vessel Number:** None
- **Category:** Intelligence vessels


## Beijixing

- **Vessel Number:** None
- **Category:** Intelligence vessels


## Kaiyangxing

- **Vessel Number:** None
- **Category:** Intelligence vessels


## Tianwangxing

- **Vessel Number:** None
- **Category:** Intelligence vessels


## Dong Ce 232

- **Vessel Number:** 232
- **Category:** Intelligence vessels


## Dong Ce 233

- **Vessel Number:** 233
- **Category:** Intelligence vessels


## Nan Ce 429

- **Vessel Number:** 429
- **Category:** Intelligence vessels


## Nan Ce 430

- **Vessel Number:** 430
- **Category:** Intelligence vessels


## �

- **Vessel Number:** 780
- **Category:** Intelligence vessels


## �

- **Vessel Number:** 781
- **Category:** Intelligence vessels


## �

- **Vessel Number:** 782
- **Category:** Intelligence vessels


## �

- **Vessel Number:** 783
- **Category:** Intelligence vessels


## Jiangmen

- **Vessel Number:** None
- **Category:** Training ships


## Zhaoqing

- **Vessel Number:** None
- **Category:** Training ships


## Zheng He

- **Vessel Number:** 81
- **Category:** Training ships


## Shichang

- **Vessel Number:** 82
- **Category:** Training ships


## Qi Jiguang

- **Vessel Number:** 83
- **Category:** Training ships


## Polang

- **Vessel Number:** 86
- **Category:** Training ships


## Hong Hu

- **Vessel Number:** None
- **Category:** Principal auxiliaries


## Xu Xiake

- **Vessel Number:** 88
- **Category:** Principal auxiliaries


## �

- **Vessel Number:** 89
- **Category:** Principal auxiliaries


## Chagan Hu

- **Vessel Number:** 905
- **Category:** Principal auxiliaries


## Hong Hu

- **Vessel Number:** 906
- **Category:** Principal auxiliaries


## Luoma Hu

- **Vessel Number:** 907
- **Category:** Principal auxiliaries


## Junshan Hu

- **Vessel Number:** 961
- **Category:** Principal auxiliaries


## Lugu Hu

- **Vessel Number:** 962
- **Category:** Principal auxiliaries


## CHANGZHENG 09

- **Vessel Number:** 409
- **Category:** Strategic missile submarines


## CHANGZHENG 10

- **Vessel Number:** 412
- **Category:** Strategic missile submarines


## CHANGZHENG 11

- **Vessel Number:** 413
- **Category:** Strategic missile submarines


## CHANGZHENG 12

- **Vessel Number:** 414
- **Category:** Strategic missile submarines


## CHANGZHENG 17

- **Vessel Number:** 420
- **Category:** Strategic missile submarines


## CHANGZHENG 18

- **Vessel Number:** 421
- **Category:** Strategic missile submarines