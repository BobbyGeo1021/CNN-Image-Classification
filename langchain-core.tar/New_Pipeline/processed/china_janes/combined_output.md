# Country Information


**Country Name:** China



**Country ID:** CN



**Full Name:** The People's Republic of China, proclaimed on 1 October 1949, is the world's third-largest country by area (3,695,000 square miles). It is bordered to the northwest by Kyrgyzstan, Kazakhstan, to the north by Mongolia, and Russia, to the south by Vietnam, Laos, Myanmar, India, Bhutan, and Nepal, to the east by North Korea and to the west by Pakistan, Afghanistan, and Tajikistan. It has a 7,830 n mile coastline with the Yellow, East China, and South China seas. There are more than 3,400 offshore islands of which Hainan is the largest. Sovereignty over Taiwan is also claimed. In the South China Sea there are territorial disputes between China, Brunei, Taiwan, Vietnam, Malaysia, Indonesia, and the Philippines and in the East China Sea between China, Japan, and South Korea. The principal ports are Shanghai, Qingdao, Shantou, Xiamen, Tianjin, Guangzhou, Hong Kong, Dalian, and Ningbo-Zhoushan. Overall there are 54,000 n miles of navigable inland waterways including the Yangtze River on which the port of Wuhan is situated. Territorial seas (12 n miles) are claimed. A 200 n mile exclusive economic zone (EEZ) has also been claimed but the limits have not been defined.



**Region Description:** PEOPLE�S LIBERATION ARMY NAVY (PLAN)



**Headquarter Appointments:** * Commander-in-chief of the Navy: Admiral Dong Jun * Political Commissar of the Navy: Admiral Yuan Huazhi * Chief of Naval Staff: To be announced



**Fleet Commanders:** * Northern Theatre Navy Commander: Vice Admiral Wang Dazhong * Eastern Theatre Navy Commander: Vice Admiral Wang Zhaocai * Southern Theatre Navy Commander: Vice Admiral Wang Hai



**Personnel:** (a) 2021: 235,000 officers and men, including 25,000 naval air force, 8�10,000 marines (28,000 in time of war), and 28,000 for coastal defence. (b) 2 years� national service for sailors afloat; 3 years for those in shore service. Some stay on for up to 15 years. 41,000 conscripts.



**Operational Numbers:** Because numbers of vessels are kept in operational reserve, the Chinese version of the order of battle tends to show fewer ships than are counted by observers.



**Organization:** Fleets report to joint theatre commands since 2017. The Northern Theatre Fleet is responsible for the defence of the Yellow Sea and Bohai Sea as well as the maritime gateway to Beijing. The Eastern Theatre Fleet is responsible for the defence of the East China Sea and the Yellow Sea south of Lianyungang, and the north of the Taiwan Strait. The Southern Theatre Fleet is responsible for the South China Sea and the southern part of the Taiwan Strait, including protecting maritime interests in the south, including the Xisha Islands (Paracel Islands) and the Nansha Islands (Spratly Islands). Each of the Northern, Eastern, and Southern fleets has two submarine divisions, four or more destroyer/frigate (DD/FF) units and at least one mine countermeasure vessel (MCMV) unit. They also have at least one landing division each. All fleets have at least one submarine unit and two Marine brigades.



**Bases:** * Northern Theatre Fleet. Major bases: Qingdao (HQ), Lushun, Huludao. Other bases: Dalian, Xiaopingdao (Dalian), Qinhuangdao, Weihai, Chengshan, Qingdao (Guzhankou, Taolin), Jianggezhuang (Nanyao-wan, Laoshan). * Eastern Theatre Fleet. Major bases: Ningbo (HQ), Shanghai, Zhoushan. Other bases: Xiangshan, Fujian (Fuzhou), Dinghai, Wusong (Shanghai), Wuhan and Daxie dao. * Southern Theatre Fleet. Major bases: Zhanjiang (HQ), Guangzhou, Yulin. Other bases: Beihai, Xiachuan Island, Yalong Bay (Sanya), Shantou Harbour, Angchuanzhou (Stonecutter�s Island, Hong Kong).



**Coast Defence:** There are semi-fixed sites and mobile coastal defence units equipped with surface-to-surface missiles (SSMs), including the YJ-62 and some with supersonic YJ-12B. There are air defence brigades equipped with HQ-9, HQ-6A, and short-range missiles and guns. Southern Theatre air defence units can be forward deployed to islands. The PLA further operates coastal defence brigades equipped with artillery and MLRS.



**Training:** The main training centres are: * Dalian: Naval Academy * Guangzhou: Naval Arms Command College * Qingdao: Submarine Academy * Wuhan: Naval Engineering University * Nanjing: Naval Command College * Yantai: Naval Aeronautical Engineering College * Bengbu: Naval School for Non-Commissioned Officers



**Marines:** Structure changed in 2017 and expanding to eight brigades with conversion of four former PLA units (3rd�6th brigade), establishment of new 7th aviation brigade, and merging naval combat divers and amphibious reconnaissance units of existing two brigades into 8th special forces brigade. HQ, PLANMC, Chaozhou, Guangdong region 1st Brigade, Southern Theatre, Zhanjiang, Guangdong. 2nd Brigade, Southern Theatre, Zhanjiang, Guangdong. 3rd Brigade, Eastern Theatre, Jinjiang, Fujian. 4th Brigade, Eastern Theatre, Jieyang, Guangdong. 5th Brigade, Northern Theatre, Laoshan, Shandong. 6th Brigade, Northern Theatre, Haiyang, Shandong. 7th Aviation Brigade, Zhucheng, Shandong. 8th Special Forces Brigade Jialong (Dragons), Sanya, Hainan.



**Naval Airforce:** With 25,000 officers and men and more than 800 aircraft, this is a considerable naval air force primarily land-based. There is a total of eight Divisions with 27 Regiments split between the three Fleets. Air bases include: * Northern Theatre Fleet: Dalian, Qingdao, Jinxi, Jiyuan, Laiyang, Jiaoxian, Xingtai, Laishan, Anyang, Changzhi, Liangxiang and Shan Hai Guan. * Eastern Theatre Fleet: Danyang, Daishan, Shanghai (Dachang), Ningbo, Luqiao, Feidong and Shitangqiao. * Southern Theatre Fleet: Foluo, Haikou, Lingshui, Sanya, Guiping, Jialaishi and Lingling.



**Fleet Strength:**

- SSBN: 6 (4)

- SSN: 9 2

- SSK/SSG: 56 (5)

- SSA: 1 �

- Aircraft carriers: 2 1 (2)

- Destroyers: 50 9 (2)

- Frigates: 44 6 (10)

- Corvettes: 50 �

- Fast attack craft (missile): 82 �

- Patrol craft: 6 �

- LPDs: 8 �

- LHDs: 3 (5)

- LSTs: 30 �

- LSMs: 22 �

- MCMVs: 42 �

- Survey/research: 17 �

- Space tracking ships: 4 �

- Intelligence vessels: 22 2

- Training ships: 6 �

- Submarine support ships: 10 �

- Supply ships: 13 �

- Fleet replenishment ships: 12 (4)

- Support tankers: 45 �

- Hospital ships: 8 1

- Icebreakers: 2 �




**Deletions:**

- Destroyers: 2020: Zhanjiang, Zhuhai; 2021: Dandong, Zhaotong

- Frigates: 2022: Beihai, Foshan, Shaoguan

- Corvettes: 2021: Baoding, Bengbu, Huizhou, Ji'an, Jieyang, Huai'an, Huizhou, Huai'an, Meizhou, Shangrao, Suzhou; 2022: Heze, Quanzhou

- Auxiliaries: 2020: Poyang Hu

---


# Pennant List


## Changzheng 03

- **Vessel Number:** 403
- **Category:** Nuclear submarines


## Changzheng 04

- **Vessel Number:** 404
- **Category:** Nuclear submarines


## Changzheng 05

- **Vessel Number:** 405
- **Category:** Nuclear submarines


## Changzheng 07

- **Vessel Number:** 407
- **Category:** Nuclear submarines


## Changzheng 08

- **Vessel Number:** 408
- **Category:** Nuclear submarines


## Changzheng 09

- **Vessel Number:** 409
- **Category:** Nuclear submarines


## Changzheng 12

- **Vessel Number:** 410
- **Category:** Nuclear submarines


## Changzheng 10

- **Vessel Number:** 412
- **Category:** Nuclear submarines


## Changzheng 11

- **Vessel Number:** 413
- **Category:** Nuclear submarines


## Changzheng 14

- **Vessel Number:** 414
- **Category:** Nuclear submarines


## Changzheng 15

- **Vessel Number:** 418
- **Category:** Nuclear submarines


## Changzheng 16

- **Vessel Number:** 419
- **Category:** Nuclear submarines


## Changzheng 17

- **Vessel Number:** 420
- **Category:** Nuclear submarines


## Changzheng 18

- **Vessel Number:** 421
- **Category:** Nuclear submarines


## Liaoning

- **Vessel Number:** 16
- **Category:** Aircraft carriers


## Shandong

- **Vessel Number:** 17
- **Category:** Aircraft carriers


## Fujian (bldg)

- **Vessel Number:** 18
- **Category:** Aircraft carriers


## Nanchang

- **Vessel Number:** 101
- **Category:** Destroyers


## Lhasa

- **Vessel Number:** 102
- **Category:** Destroyers


## Anshan

- **Vessel Number:** 103
- **Category:** Destroyers


## Wuxi

- **Vessel Number:** 104
- **Category:** Destroyers


## Dalian

- **Vessel Number:** 105
- **Category:** Destroyers


## Yan'an

- **Vessel Number:** 106
- **Category:** Destroyers


## Zunyi

- **Vessel Number:** 107
- **Category:** Destroyers


## Xianyang

- **Vessel Number:** 108
- **Category:** Destroyers


## Harbin

- **Vessel Number:** 112
- **Category:** Destroyers


## Qingdao

- **Vessel Number:** 113
- **Category:** Destroyers


## Shenyang

- **Vessel Number:** 115
- **Category:** Destroyers


## Shijiazhuang

- **Vessel Number:** 116
- **Category:** Destroyers


## Xining

- **Vessel Number:** 117
- **Category:** Destroyers


## Urumqi

- **Vessel Number:** 118
- **Category:** Destroyers


## Guiyang

- **Vessel Number:** 119
- **Category:** Destroyers


## Chengdu

- **Vessel Number:** 120
- **Category:** Destroyers


## Qiqihar

- **Vessel Number:** 121
- **Category:** Destroyers


## Tangshan

- **Vessel Number:** 122
- **Category:** Destroyers


## Huainan

- **Vessel Number:** 123
- **Category:** Destroyers


## Kaifeng

- **Vessel Number:** 124
- **Category:** Destroyers


## Taiyuan

- **Vessel Number:** 131
- **Category:** Destroyers


## Suzhou

- **Vessel Number:** 132
- **Category:** Destroyers


## Baotou

- **Vessel Number:** 133
- **Category:** Destroyers


## Shaoxing

- **Vessel Number:** 134
- **Category:** Destroyers


## Hangzhou

- **Vessel Number:** 136
- **Category:** Destroyers


## Fuzhou

- **Vessel Number:** 137
- **Category:** Destroyers


## Taizhou

- **Vessel Number:** 138
- **Category:** Destroyers


## Ningbo

- **Vessel Number:** 139
- **Category:** Destroyers


## Changchun

- **Vessel Number:** 150
- **Category:** Destroyers


## Zhengzhou

- **Vessel Number:** 151
- **Category:** Destroyers


## Jinan

- **Vessel Number:** 152
- **Category:** Destroyers


## Xi'an

- **Vessel Number:** 153
- **Category:** Destroyers


## Xiamen

- **Vessel Number:** 154
- **Category:** Destroyers


## Nanjing

- **Vessel Number:** 155
- **Category:** Destroyers


## Zibo

- **Vessel Number:** 156
- **Category:** Destroyers


## Lishui

- **Vessel Number:** 157
- **Category:** Destroyers


## Huhehaote

- **Vessel Number:** 161
- **Category:** Destroyers


## Nanning

- **Vessel Number:** 162
- **Category:** Destroyers


## Jiaozuo

- **Vessel Number:** 163
- **Category:** Destroyers


## Guilin

- **Vessel Number:** 164
- **Category:** Destroyers


## Zhanjiang

- **Vessel Number:** 165
- **Category:** Destroyers


## Shenzhen

- **Vessel Number:** 167
- **Category:** Destroyers


## Guangzhou

- **Vessel Number:** 168
- **Category:** Destroyers


## Wuhan

- **Vessel Number:** 169
- **Category:** Destroyers


## Lanzhou

- **Vessel Number:** 170
- **Category:** Destroyers


## Haikou

- **Vessel Number:** 171
- **Category:** Destroyers


## Kunming

- **Vessel Number:** 172
- **Category:** Destroyers


## Changsha

- **Vessel Number:** 173
- **Category:** Destroyers


## Hefei

- **Vessel Number:** 174
- **Category:** Destroyers


## Yinchuan

- **Vessel Number:** 175
- **Category:** Destroyers


## Xianning

- **Vessel Number:** 500
- **Category:** Frigates


## Binzhou

- **Vessel Number:** 515
- **Category:** Frigates


## Ji'an

- **Vessel Number:** 518
- **Category:** Frigates


## Jiaxing

- **Vessel Number:** 521
- **Category:** Frigates


## Ziyang

- **Vessel Number:** 522
- **Category:** Frigates


## Hebi

- **Vessel Number:** 523
- **Category:** Frigates


## Sanming

- **Vessel Number:** 524
- **Category:** Frigates


## Ma'anshan

- **Vessel Number:** 525
- **Category:** Frigates


## Wenzhou

- **Vessel Number:** 526
- **Category:** Frigates


## Luoyang

- **Vessel Number:** 527
- **Category:** Frigates


## Mianyang

- **Vessel Number:** 528
- **Category:** Frigates


## Zhoushan

- **Vessel Number:** 529
- **Category:** Frigates


## Xuzhou

- **Vessel Number:** 530
- **Category:** Frigates


## Xiangtan

- **Vessel Number:** 531
- **Category:** Frigates


## Jingzhou

- **Vessel Number:** 532
- **Category:** Frigates


## Nantong

- **Vessel Number:** 533
- **Category:** Frigates


## Xuchang

- **Vessel Number:** 536
- **Category:** Frigates


## Yixing

- **Vessel Number:** 537
- **Category:** Frigates


## Yantai

- **Vessel Number:** 538
- **Category:** Frigates


## Wuhu

- **Vessel Number:** 539
- **Category:** Frigates


## Xichang

- **Vessel Number:** 540
- **Category:** Frigates


## Zaozhuang

- **Vessel Number:** 542
- **Category:** Frigates


## Yancheng

- **Vessel Number:** 546
- **Category:** Frigates


## Linyi

- **Vessel Number:** 547
- **Category:** Frigates


## Yiyang

- **Vessel Number:** 548
- **Category:** Frigates


## Changzhou

- **Vessel Number:** 549
- **Category:** Frigates


## Weifang

- **Vessel Number:** 550
- **Category:** Frigates


## Bayannao�er

- **Vessel Number:** 551
- **Category:** Frigates


## Shaoguan

- **Vessel Number:** 553
- **Category:** Frigates


## Beihai

- **Vessel Number:** 558
- **Category:** Frigates


## Foshan

- **Vessel Number:** 559
- **Category:** Frigates


## Yichang

- **Vessel Number:** 564
- **Category:** Frigates


## Huludao

- **Vessel Number:** 565
- **Category:** Frigates


## Huaihua

- **Vessel Number:** 566
- **Category:** Frigates


## Xiangfan

- **Vessel Number:** 567
- **Category:** Frigates


## Hengyang

- **Vessel Number:** 568
- **Category:** Frigates


## Yulin

- **Vessel Number:** 569
- **Category:** Frigates


## Huangshan

- **Vessel Number:** 570
- **Category:** Frigates


## Yuncheng

- **Vessel Number:** 571
- **Category:** Frigates


## Hengshui

- **Vessel Number:** 572
- **Category:** Frigates


## Liuzhou

- **Vessel Number:** 573
- **Category:** Frigates


## Sanya

- **Vessel Number:** 574
- **Category:** Frigates


## Yueyang

- **Vessel Number:** 575
- **Category:** Frigates


## Daqing

- **Vessel Number:** 576
- **Category:** Frigates


## Huanggang

- **Vessel Number:** 577
- **Category:** Frigates


## Yangzhou

- **Vessel Number:** 578
- **Category:** Frigates


## Handan

- **Vessel Number:** 579
- **Category:** Frigates


## Rizhao

- **Vessel Number:** 598
- **Category:** Frigates


## Anyang

- **Vessel Number:** 599
- **Category:** Frigates


## Ningde

- **Vessel Number:** 510
- **Category:** Corvettes


## Heze

- **Vessel Number:** 512
- **Category:** Corvettes


## Datong

- **Vessel Number:** 580
- **Category:** Corvettes


## Yingkou

- **Vessel Number:** 581
- **Category:** Corvettes


## Baise

- **Vessel Number:** 585
- **Category:** Corvettes


## Quanzhou

- **Vessel Number:** 588
- **Category:** Corvettes


## Qingyuan

- **Vessel Number:** 589
- **Category:** Corvettes


## Weihai

- **Vessel Number:** 590
- **Category:** Corvettes


## Fushun

- **Vessel Number:** 591
- **Category:** Corvettes


## Luzhou

- **Vessel Number:** 592
- **Category:** Corvettes


## Chaozhou

- **Vessel Number:** 595
- **Category:** Corvettes


## Qinzhou

- **Vessel Number:** 597
- **Category:** Corvettes


## Songyuan

- **Vessel Number:** 600
- **Category:** Corvettes


## Wuhai

- **Vessel Number:** 601
- **Category:** Corvettes


## Pingdingshan

- **Vessel Number:** 602
- **Category:** Corvettes


## Dingzhou

- **Vessel Number:** 603
- **Category:** Corvettes


## Mudanjiang

- **Vessel Number:** 604
- **Category:** Corvettes


## Zhangjiakou

- **Vessel Number:** 605
- **Category:** Corvettes


## Dongying

- **Vessel Number:** 606
- **Category:** Corvettes


## Laiwu

- **Vessel Number:** 607
- **Category:** Corvettes


## Liaocheng

- **Vessel Number:** 608
- **Category:** Corvettes


## Shizuishan

- **Vessel Number:** 609
- **Category:** Corvettes


## Shuozhou

- **Vessel Number:** 610
- **Category:** Corvettes


## Lu'an

- **Vessel Number:** 611
- **Category:** Corvettes


## Xiaogan

- **Vessel Number:** 615
- **Category:** Corvettes


## Tai'an

- **Vessel Number:** 616
- **Category:** Corvettes


## Jingdezhen

- **Vessel Number:** 617
- **Category:** Corvettes


## Shangqiu

- **Vessel Number:** 618
- **Category:** Corvettes


## Nanyang

- **Vessel Number:** 619
- **Category:** Corvettes


## Ganzhou

- **Vessel Number:** 620
- **Category:** Corvettes


## Panzhihua

- **Vessel Number:** 621
- **Category:** Corvettes


## Guang'an

- **Vessel Number:** 622
- **Category:** Corvettes


## Wenshan

- **Vessel Number:** 623
- **Category:** Corvettes


## Suizhou

- **Vessel Number:** 624
- **Category:** Corvettes


## Bazhong

- **Vessel Number:** 625
- **Category:** Corvettes


## Wuzhou

- **Vessel Number:** 626
- **Category:** Corvettes


## Enshi

- **Vessel Number:** 627
- **Category:** Corvettes


## Yongzhou

- **Vessel Number:** 628
- **Category:** Corvettes


## Tongling

- **Vessel Number:** 629
- **Category:** Corvettes


## Aba

- **Vessel Number:** 630
- **Category:** Corvettes


## Tianmen

- **Vessel Number:** 631
- **Category:** Corvettes


## Jining

- **Vessel Number:** 636
- **Category:** Corvettes


## Shiyan

- **Vessel Number:** 637
- **Category:** Corvettes


## Sanmenxia

- **Vessel Number:** 638
- **Category:** Corvettes


## Zhuzhou

- **Vessel Number:** 639
- **Category:** Corvettes


## Ezhou

- **Vessel Number:** 640
- **Category:** Corvettes


## Yiwu

- **Vessel Number:** 641
- **Category:** Corvettes


## Deyang

- **Vessel Number:** 642
- **Category:** Corvettes


## Yichun

- **Vessel Number:** 643
- **Category:** Corvettes


## Xuancheng

- **Vessel Number:** 645
- **Category:** Corvettes


## Suining

- **Vessel Number:** 646
- **Category:** Corvettes


## Nanchong

- **Vessel Number:** 647
- **Category:** Corvettes


## Hanzhong

- **Vessel Number:** 648
- **Category:** Corvettes


## Guangyuan

- **Vessel Number:** 649
- **Category:** Corvettes


## Zhangye

- **Vessel Number:** 654
- **Category:** Corvettes


## Huangshi

- **Vessel Number:** 655
- **Category:** Corvettes


## Qinhuangdao

- **Vessel Number:** 656
- **Category:** Corvettes


## Suqian

- **Vessel Number:** 666
- **Category:** Corvettes


## Tongren

- **Vessel Number:** 664
- **Category:** Corvettes


## Jingmen

- **Vessel Number:** 667
- **Category:** Corvettes


## Qujing

- **Vessel Number:** 668
- **Category:** Corvettes


## Liupanshui

- **Vessel Number:** 669
- **Category:** Corvettes


## Hainan

- **Vessel Number:** 31
- **Category:** Principal amphibious warfare units


## Guangxi

- **Vessel Number:** 32
- **Category:** Principal amphibious warfare units


## Anhui

- **Vessel Number:** 33
- **Category:** Principal amphibious warfare units


## Yandan Shan

- **Vessel Number:** 908
- **Category:** Principal amphibious warfare units


## Jiuhua Shan

- **Vessel Number:** 909
- **Category:** Principal amphibious warfare units


## Huanggang Shan

- **Vessel Number:** 910
- **Category:** Principal amphibious warfare units


## Tianzhu Shan

- **Vessel Number:** 911
- **Category:** Principal amphibious warfare units


## Daqing Shan

- **Vessel Number:** 912
- **Category:** Principal amphibious warfare units


## Baxien Shan

- **Vessel Number:** 913
- **Category:** Principal amphibious warfare units


## Wuyi Shan

- **Vessel Number:** 914
- **Category:** Principal amphibious warfare units


## Culai Shan

- **Vessel Number:** 915
- **Category:** Principal amphibious warfare units


## Tianmu Shan

- **Vessel Number:** 916
- **Category:** Principal amphibious warfare units


## Wutai Shan

- **Vessel Number:** 917
- **Category:** Principal amphibious warfare units


## Lingyan Shan

- **Vessel Number:** 930
- **Category:** Principal amphibious warfare units


## Dongting Shan

- **Vessel Number:** 931
- **Category:** Principal amphibious warfare units


## Helan Shan

- **Vessel Number:** 932
- **Category:** Principal amphibious warfare units


## Liupan Shan

- **Vessel Number:** 933
- **Category:** Principal amphibious warfare units


## Danxia Shan

- **Vessel Number:** 934
- **Category:** Principal amphibious warfare units


## Xuefeng Shan

- **Vessel Number:** 935
- **Category:** Principal amphibious warfare units


## Haiyang Shan

- **Vessel Number:** 936
- **Category:** Principal amphibious warfare units


## Qingcheng Shan

- **Vessel Number:** 937
- **Category:** Principal amphibious warfare units


## Putuo Shan

- **Vessel Number:** 939
- **Category:** Principal amphibious warfare units


## Tiantai Shan

- **Vessel Number:** 940
- **Category:** Principal amphibious warfare units


## Longhu Shan

- **Vessel Number:** 980
- **Category:** Principal amphibious warfare units


## Dabie Shan

- **Vessel Number:** 981
- **Category:** Principal amphibious warfare units


## Taihang Shan

- **Vessel Number:** 982
- **Category:** Principal amphibious warfare units


## Qilian Shan

- **Vessel Number:** 985
- **Category:** Principal amphibious warfare units


## Wanyang Shan

- **Vessel Number:** 986
- **Category:** Principal amphibious warfare units


## Wuzhi Shan

- **Vessel Number:** 987
- **Category:** Principal amphibious warfare units


## Yimeng Shan

- **Vessel Number:** 988
- **Category:** Principal amphibious warfare units


## Changbai Shan

- **Vessel Number:** 989
- **Category:** Principal amphibious warfare units


## Emei Shan

- **Vessel Number:** 991
- **Category:** Principal amphibious warfare units


## Huading Shan

- **Vessel Number:** 992
- **Category:** Principal amphibious warfare units


## Luoxiao Shan

- **Vessel Number:** 993
- **Category:** Principal amphibious warfare units


## Daiyun Shan

- **Vessel Number:** 994
- **Category:** Principal amphibious warfare units


## Wanyan Shan

- **Vessel Number:** 995
- **Category:** Principal amphibious warfare units


## Laotie Shan

- **Vessel Number:** 996
- **Category:** Principal amphibious warfare units


## Yunwu Shan

- **Vessel Number:** 997
- **Category:** Principal amphibious warfare units


## Kunlun Shan

- **Vessel Number:** 998
- **Category:** Principal amphibious warfare units


## Jinggang Shan

- **Vessel Number:** 999
- **Category:** Principal amphibious warfare units


## Fenghua

- **Vessel Number:** 703
- **Category:** Principal amphibious warfare units


## Huoqiu

- **Vessel Number:** 704
- **Category:** Principal amphibious warfare units


## Zhangjiagang

- **Vessel Number:** 705
- **Category:** Principal amphibious warfare units


## Jingjiang

- **Vessel Number:** 706
- **Category:** Principal amphibious warfare units


## Kunshan

- **Vessel Number:** 707
- **Category:** Principal amphibious warfare units


## Renhuai

- **Vessel Number:** 710
- **Category:** Principal amphibious warfare units


## Jiangshan

- **Vessel Number:** 711
- **Category:** Principal amphibious warfare units


## Rudong

- **Vessel Number:** 712
- **Category:** Principal amphibious warfare units


## Zhuji

- **Vessel Number:** 713
- **Category:** Principal amphibious warfare units


## �

- **Vessel Number:** 714
- **Category:** Principal amphibious warfare units


## Wenling

- **Vessel Number:** 715
- **Category:** Principal amphibious warfare units


## Pingdu

- **Vessel Number:** 720
- **Category:** Principal amphibious warfare units


## Changyi

- **Vessel Number:** 721
- **Category:** Principal amphibious warfare units


## Yangshuo

- **Vessel Number:** 722
- **Category:** Principal amphibious warfare units


## Yongsheng

- **Vessel Number:** 723
- **Category:** Principal amphibious warfare units


## Daxin

- **Vessel Number:** 724
- **Category:** Principal amphibious warfare units


## Huarong

- **Vessel Number:** 725
- **Category:** Principal amphibious warfare units


## Rongjiang

- **Vessel Number:** 726
- **Category:** Principal amphibious warfare units


## Qionghai

- **Vessel Number:** 727
- **Category:** Principal amphibious warfare units


## Hejian

- **Vessel Number:** 728
- **Category:** Principal amphibious warfare units


## Chishui

- **Vessel Number:** 729
- **Category:** Principal amphibious warfare units


## Qingzhou

- **Vessel Number:** 730
- **Category:** Principal amphibious warfare units


## Yucheng

- **Vessel Number:** 731
- **Category:** Principal amphibious warfare units


## Wudi

- **Vessel Number:** 732
- **Category:** Principal amphibious warfare units


## Xuanwei

- **Vessel Number:** 733
- **Category:** Principal amphibious warfare units


## Rongcheng

- **Vessel Number:** 734
- **Category:** Principal amphibious warfare units


## Huimin

- **Vessel Number:** 735
- **Category:** Principal amphibious warfare units


## Donggang

- **Vessel Number:** 736
- **Category:** Principal amphibious warfare units


## Zhijiang

- **Vessel Number:** 737
- **Category:** Principal amphibious warfare units


## Chibi

- **Vessel Number:** 738
- **Category:** Principal amphibious warfare units


## �

- **Vessel Number:** 739
- **Category:** Principal amphibious warfare units


## Xiaoyi

- **Vessel Number:** 741
- **Category:** Principal amphibious warfare units


## Taishan

- **Vessel Number:** 742
- **Category:** Principal amphibious warfare units


## Changshu

- **Vessel Number:** 743
- **Category:** Principal amphibious warfare units


## Heshan

- **Vessel Number:** 744
- **Category:** Principal amphibious warfare units


## Luxi

- **Vessel Number:** 745
- **Category:** Principal amphibious warfare units


## Kaiping

- **Vessel Number:** 746
- **Category:** Principal amphibious warfare units


## ex-806 Zhijiang

- **Vessel Number:** None
- **Category:** Principal amphibious warfare units


## ex-816 Haimen

- **Vessel Number:** None
- **Category:** Principal amphibious warfare units


## ex-839 Liuyang

- **Vessel Number:** None
- **Category:** Principal amphibious warfare units


## Bi Sheng

- **Vessel Number:** 891
- **Category:** Principal amphibious warfare units


## Hua Luogeng

- **Vessel Number:** 892
- **Category:** Principal amphibious warfare units


## Zhong Tianyou

- **Vessel Number:** 893
- **Category:** Principal amphibious warfare units


## Li Siguang

- **Vessel Number:** 894
- **Category:** Principal amphibious warfare units


## Wu Yunyu

- **Vessel Number:** 895
- **Category:** Principal amphibious warfare units


## Haiwanxing

- **Vessel Number:** 792
- **Category:** Principal amphibious warfare units


## Tianlangxing

- **Vessel Number:** 794
- **Category:** Principal amphibious warfare units


## Tianshuxing

- **Vessel Number:** 795
- **Category:** Principal amphibious warfare units


## Tianquanxing

- **Vessel Number:** 797
- **Category:** Principal amphibious warfare units


## Yuhengxing

- **Vessel Number:** 798
- **Category:** Principal amphibious warfare units


## Jinxing

- **Vessel Number:** 799
- **Category:** Principal amphibious warfare units


## Dong Biao 265

- **Vessel Number:** 265
- **Category:** Principal amphibious warfare units


## Nan Biao 467

- **Vessel Number:** 467
- **Category:** Principal amphibious warfare units


## Changxing Dao

- **Vessel Number:** 861
- **Category:** Principal amphibious warfare units


## Chongming Dao

- **Vessel Number:** 862
- **Category:** Principal amphibious warfare units


## Yongxing Dao

- **Vessel Number:** 863
- **Category:** Principal amphibious warfare units


## Haiyang Dao

- **Vessel Number:** 864
- **Category:** Principal amphibious warfare units


## Liugong Dao

- **Vessel Number:** 865
- **Category:** Principal amphibious warfare units


## Daishan Dao

- **Vessel Number:** 866
- **Category:** Principal amphibious warfare units


## Daishan Dao

- **Vessel Number:** 867
- **Category:** Principal amphibious warfare units


## Donghai Dao

- **Vessel Number:** 868
- **Category:** Principal amphibious warfare units


## Qinghai Hu

- **Vessel Number:** 885
- **Category:** Principal amphibious warfare units


## Qiandao Hu

- **Vessel Number:** 886
- **Category:** Principal amphibious warfare units


## Weishan Hu

- **Vessel Number:** 887
- **Category:** Principal amphibious warfare units


## Fuxian Hu

- **Vessel Number:** 888
- **Category:** Principal amphibious warfare units


## Tai Hu

- **Vessel Number:** 889
- **Category:** Principal amphibious warfare units


## Chao Hu

- **Vessel Number:** 890
- **Category:** Principal amphibious warfare units


## Hulun Hu

- **Vessel Number:** 901
- **Category:** Principal amphibious warfare units


## Dongping Hu

- **Vessel Number:** 902
- **Category:** Principal amphibious warfare units


## Hoh Xil Hu

- **Vessel Number:** 903
- **Category:** Principal amphibious warfare units


## Gaoyao Hu

- **Vessel Number:** 904
- **Category:** Principal amphibious warfare units


## Xiangshan

- **Vessel Number:** 701
- **Category:** Principal mine warfare forces


## Chongming

- **Vessel Number:** 702
- **Category:** Principal mine warfare forces


## Zhu Khezen

- **Vessel Number:** 872
- **Category:** Principal survey and research ships


## Qian Xuesen

- **Vessel Number:** 873
- **Category:** Principal survey and research ships


## Deng Jiaxian

- **Vessel Number:** 874
- **Category:** Principal survey and research ships


## Qian Sanqiang

- **Vessel Number:** 875
- **Category:** Principal survey and research ships


## Qian Weichang

- **Vessel Number:** 876
- **Category:** Principal survey and research ships


## Bei Ce 901

- **Vessel Number:** None
- **Category:** Intelligence vessels


## Bei Ce 902

- **Vessel Number:** None
- **Category:** Intelligence vessels


## Bei Diao 900

- **Vessel Number:** None
- **Category:** Intelligence vessels


## Bei Diao 990

- **Vessel Number:** None
- **Category:** Intelligence vessels


## Bei Diao 991

- **Vessel Number:** None
- **Category:** Intelligence vessels


## Beijixing

- **Vessel Number:** None
- **Category:** Intelligence vessels


## Kaiyangxing

- **Vessel Number:** None
- **Category:** Intelligence vessels


## Tianwangxing

- **Vessel Number:** None
- **Category:** Intelligence vessels


## Dong Ce 232

- **Vessel Number:** 232
- **Category:** Intelligence vessels


## Dong Ce 233

- **Vessel Number:** 233
- **Category:** Intelligence vessels


## Nan Ce 429

- **Vessel Number:** 429
- **Category:** Intelligence vessels


## Nan Ce 430

- **Vessel Number:** 430
- **Category:** Intelligence vessels


## �

- **Vessel Number:** 780
- **Category:** Intelligence vessels


## �

- **Vessel Number:** 781
- **Category:** Intelligence vessels


## �

- **Vessel Number:** 782
- **Category:** Intelligence vessels


## �

- **Vessel Number:** 783
- **Category:** Intelligence vessels


## Jiangmen

- **Vessel Number:** None
- **Category:** Training ships


## Zhaoqing

- **Vessel Number:** None
- **Category:** Training ships


## Zheng He

- **Vessel Number:** 81
- **Category:** Training ships


## Shichang

- **Vessel Number:** 82
- **Category:** Training ships


## Qi Jiguang

- **Vessel Number:** 83
- **Category:** Training ships


## Polang

- **Vessel Number:** 86
- **Category:** Training ships


## Hong Hu

- **Vessel Number:** None
- **Category:** Principal auxiliaries


## Xu Xiake

- **Vessel Number:** 88
- **Category:** Principal auxiliaries


## �

- **Vessel Number:** 89
- **Category:** Principal auxiliaries


## Chagan Hu

- **Vessel Number:** 905
- **Category:** Principal auxiliaries


## Hong Hu

- **Vessel Number:** 906
- **Category:** Principal auxiliaries


## Luoma Hu

- **Vessel Number:** 907
- **Category:** Principal auxiliaries


## Junshan Hu

- **Vessel Number:** 961
- **Category:** Principal auxiliaries


## Lugu Hu

- **Vessel Number:** 962
- **Category:** Principal auxiliaries


## CHANGZHENG 09

- **Vessel Number:** 409
- **Category:** Strategic missile submarines


## CHANGZHENG 10

- **Vessel Number:** 412
- **Category:** Strategic missile submarines


## CHANGZHENG 11

- **Vessel Number:** 413
- **Category:** Strategic missile submarines


## CHANGZHENG 12

- **Vessel Number:** 414
- **Category:** Strategic missile submarines


## CHANGZHENG 17

- **Vessel Number:** 420
- **Category:** Strategic missile submarines


## CHANGZHENG 18

- **Vessel Number:** 421
- **Category:** Strategic missile submarines