from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any, Union
from enum import Enum
from pathlib import Path


# ── Schema Selection ───────────────────────────────────────────────────────────

class SchemaType(str, Enum):
    extract_pennant_list = "extract_pennant_list"
    extract_country = "extract_country"
    # NOTE: extract_class intentionally removed from pipeline.
    # ClassInfoList and ClassInformation models are retained below for future use.


class SchemaSelection(BaseModel):
    selected_schemas: List[SchemaType]


# ── Vessel & Class Models (retained for future use — not used in pipeline) ─────

class Vessel(BaseModel):
    """Vessel information"""
    vessel_no: int = Field(..., description="Vessel Number (e.g., 409)")
    class_type_id: str = Field(..., description="Foreign Key to ClassInformation")
    vessel_name: str = Field(..., description="Vessel Name")
    builders: str
    laid_down: Optional[str] = None
    launched: Optional[str] = None
    comissioned: Optional[str] = None


class ClassInformation(BaseModel):
    """Class type information for vessels — retained for future use, not used in current pipeline."""
    sub_category_value_explanation: str = Field(..., description="")
    category_value_explanation: str = Field(..., description="")
    class_type_name: str = Field(
        ...,
        description="The Class Type ID is the formal technical designator (e.g., TYPE 094) found within parentheses in the class header that provides the specific numerical project code for that Class Type Name.",
    )
    category: Optional[str] = Field(
        ...,
        description="A high-level grouping that identifies the general domain and vessel type (e.g., Submarines, Surface Combatants, or Support Ships).",
    )
    category_conf: float = Field(
        ...,
        description="Confidence in the correctness of the answer for the category field",
    )
    sub_category: Optional[str] = Field(
        ...,
        description="A specialized classification that defines the functional purpose, armament capability, or operational doctrine of the vessel (e.g., Strategic Missile, Attack, or Coastal Defense).",
    )
    sub_category_conf: float = Field(
        ...,
        description="Confidence in the correctness of the answer for the sub-category field",
    )
    hull_classification_symbol: str = Field(..., description="Hull Symbol (SSBN)")
    displacement_tonnes_dived: Optional[float] = None
    displacement_tonnes_surfaced: Optional[float] = None
    dimensions_meter: Optional[List[float]] = None
    complement: Optional[str] = None
    propulsion_type: Optional[str] = None
    machinery_details: Optional[str] = None
    armament_missile: Optional[str] = None
    armament_torpedo: Optional[str] = None
    armamement_mines: Optional[str] = None
    armament_guns: Optional[str] = None
    armament_as_mortars: Optional[str] = None
    weapon_control_systems: Optional[str] = None
    physical_countermeasures: Optional[str] = None
    electronic_countermeasures: Optional[str] = None
    fixed_wing_aircrafts: Optional[str] = None
    helicopters: Optional[str] = None
    range: Optional[str] = None
    aircraft_lift: Optional[str] = None
    flight_deck: Optional[str] = None
    radars: Optional[str] = None
    sonars: Optional[str] = None
    combat_data_systems: Optional[str] = None
    programmes: Optional[str] = None
    structure: Optional[str] = None
    operational: Optional[str] = None
    modernization: Optional[str] = None
    comments: Optional[str] = None
    speed_knots_surface: Optional[float] = None
    speed_knots_dived: Optional[float] = None
    vessels: Optional[List[Vessel]] = None
    figures: Optional[List[Dict]] = None


class ClassInfoList(BaseModel):
    """Retained for future use — not used in current pipeline."""
    detected_classes: List[ClassInformation]


# ── Active Extraction Models ───────────────────────────────────────────────────

class Pennant(BaseModel):
    """Individual vessel entry from the pennant list."""
    vessel_name: str
    vessel_no: Optional[int] = None
    category: str


class PennantList(BaseModel):
    """Full pennant list extracted from a page."""
    pennants: List[Pennant]


class Country(BaseModel):
    """Country-level naval overview information.
    NOTE: Schema may evolve — fields are intentionally kept flexible with Optional."""
    country_id: str = Field(..., description="Unique Identifier (e.g., CN)")
    name: str = Field(..., description="Short Name (e.g., China)")
    full_name: Optional[str] = None
    region_description: Optional[str] = None
    headquarter_appointments: Optional[str] = None
    fleet_commanders: Optional[str] = None
    personnel: Optional[str] = None
    operational_numbers: Optional[str] = None
    organization: Optional[str] = None
    bases: Optional[str] = None
    coast_defence: Optional[str] = None
    training: Optional[str] = None
    marines: Optional[str] = None
    naval_airforce: Optional[str] = None
    fleet_strength: Optional[Dict[str, Any]] = None
    deletions: Optional[Dict[str, Any]] = None


# ── Graph State Models ─────────────────────────────────────────────────────────


class RollingContext(BaseModel):
    """Rolling context carried forward across page iterations.
    Used in: single_page_graph.py, graph.py"""
    country_name: Optional[str] = None
    last_pennant_category: Optional[str] = None

class PageExtractionState(BaseModel):
    """State for a single page extraction pass.
    Used in: single_page_graph.py"""
    img_path: Path
    rolling_context: RollingContext
    selected_schemas: Optional[List[SchemaType]] = None
    ocr_text: Optional[str] = None              # populated by ocr_node (Chandra OCR output)
    outputs: List[Union[PennantList, Country]] = Field(default_factory=list)
    figures: Optional[List[Dict]] = None        # retained, unused in current pipeline


class FigureClassification(BaseModel):
    """Retained for future use — not used in current pipeline."""
    selected_id: str = Field(
        ...,
        description="The class_type_name of the most relevant vessel class (e.g., TYPE 094)",
    )
    confidence: float = Field(
        ...,
        description="Confidence score between 0 and 1 for the classification",
        ge=0.0,
        le=1.0,
    )
    reasoning: str = Field(
        ...,
        description="Brief explanation for why this class was selected",
    )


class StructuredOutput(BaseModel):
    """Structured entities extracted from a single page.
    Used in: graph.py"""
    country: Optional[Country] = None
    pennant_list: Optional[PennantList] = None
    # class_info_list removed — ClassInfoList model retained above for future use


class PageOutput(BaseModel):
    """Final output object for a single page.
    Used in: graph.py"""
    structured_output: StructuredOutput
    markdown: Optional[str] = None


class DirectoryProcessingState(BaseModel):
    """Top-level state shared across all graph.py nodes.
    Used in: graph.py"""
    input_dir: Path
    rolling_context: RollingContext
    doc_name: str
    schema_hash: str
    page_extraction_results: Dict[Path, PageExtractionState] = Field(default_factory=dict)
    # figure_extraction_results removed — figure processing not in current pipeline
    page_outputs: Dict[str, PageOutput] = Field(default_factory=dict)
    combined_output: Dict[str, Any] = Field(default_factory=dict)
    combined_markdown: Optional[str] = None